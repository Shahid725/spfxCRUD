import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IHellowebpartProps {
    description: any;
    isDarkTheme: any;
    environmentMessage: any;
    hasTeamsContext: any;
    userDisplayName: any;
    context: WebPartContext;
    siteUrl: any;
}
//# sourceMappingURL=IHellowebpartProps.d.ts.map