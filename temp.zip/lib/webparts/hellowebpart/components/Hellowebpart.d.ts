import * as React from 'react';
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "antd/dist/antd.css";
import { IHellowebpartProps } from './IHellowebpartProps';
declare const Hellowebpart: React.FC<IHellowebpartProps>;
export default Hellowebpart;
//# sourceMappingURL=Hellowebpart.d.ts.map