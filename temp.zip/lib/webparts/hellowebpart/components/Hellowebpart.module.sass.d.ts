declare const styles: {
    verticalline: string;
    Ousername: string;
    Oposition: string;
    tag: string;
    icon: string;
    ass1: string;
    ass2: string;
    line: string;
    hrline: string;
};
export default styles;
//# sourceMappingURL=Hellowebpart.module.sass.d.ts.map