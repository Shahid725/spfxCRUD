declare const styles: {
    hellowebpart: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=Hellowebpart.module.scss.d.ts.map