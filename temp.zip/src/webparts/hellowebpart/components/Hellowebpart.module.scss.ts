/* tslint:disable */
require("./Hellowebpart.module.css");
const styles = {
  hellowebpart: 'hellowebpart_021d9f21',
  teams: 'teams_021d9f21',
  welcome: 'welcome_021d9f21',
  welcomeImage: 'welcomeImage_021d9f21',
  links: 'links_021d9f21'
};

export default styles;
/* tslint:enable */