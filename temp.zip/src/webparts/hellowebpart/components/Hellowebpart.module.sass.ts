/* tslint:disable */
require("./Hellowebpart.module.css");
const styles = {
  verticalline: 'verticalline_ea1a9e30',
  Ousername: 'Ousername_ea1a9e30',
  Oposition: 'Oposition_ea1a9e30',
  tag: 'tag_ea1a9e30',
  icon: 'icon_ea1a9e30',
  ass1: 'ass1_ea1a9e30',
  ass2: 'ass2_ea1a9e30',
  line: 'line_ea1a9e30',
  hrline: 'hrline_ea1a9e30'
};

export default styles;
/* tslint:enable */